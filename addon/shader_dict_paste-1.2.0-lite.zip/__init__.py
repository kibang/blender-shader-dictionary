# -*- coding: utf-8 -*-
# 블렌더 쉐이더 사전 — 클립보드 붙여넣기 애드온 v1.2 / Blender Shader Dictionary — clipboard paste add-on
# 사전 앱의 '블렌더로 복사' 버튼이 복사한 JSON을 읽어 노드 트리를 그대로 만들어 줍니다.
# The app's 'Copy to Blender' button copies JSON; this add-on rebuilds the node tree from it.
# 설치/Install: Edit > Preferences > Get Extensions(또는 Add-ons) > ▾ > Install from Disk... > 이 zip 선택 (Blender 4.2 ~ 5.3)
# 사용/Use: Shader Editor > N > '쉐이더 사전'(Shader Dict) 탭 > [새 재질로 붙여넣기] / [지금 재질에 섞어 넣기]
bl_info = {
    "name": "쉐이더 사전 붙여넣기 (Shader Dictionary Paste)",
    "author": "블렌더 쉐이더 사전",
    "version": (1, 2, 0),
    "blender": (4, 2, 0),
    "location": "Shader Editor > N 사이드바 > 쉐이더 사전",
    "description": "쉐이더 사전 앱에서 '블렌더로 복사'한 노드 트리를 붙여넣습니다 / Pastes node trees copied with 'Copy to Blender'",
    "category": "Node",
}

import bpy, json, os
from collections import defaultdict

try:
    from . import compat_tables as _CT        # generated: default values that differ between Blender 4.5 and 5.x
except Exception:
    try:
        import compat_tables as _CT
    except Exception:
        _CT = None


# ------------------------------------------------------------------ language (Korean / English)
def _lang():
    pr = _addon_prefs()
    ch = getattr(pr, "ui_language", "AUTO") if pr is not None else "AUTO"
    if ch in ("KO", "EN"):
        return ch
    try:
        loc = bpy.app.translations.locale or ""
        if loc.startswith("ko"):
            return "KO"
        if loc and loc not in ("en_US", "en_GB", "C"):
            return "EN"
    except Exception:
        pass
    try:
        import locale as _lc
        l = (_lc.getlocale()[0] or os.environ.get("LANG", "") or "")
        if l.lower().startswith(("ko", "korean")):
            return "KO"
    except Exception:
        pass
    return "EN"


def _t(ko, en):
    return ko if _lang() == "KO" else en

FMT = "blender-shader-dict"
OUTPUT_TYPES = {"ShaderNodeOutputMaterial", "ShaderNodeOutputWorld", "ShaderNodeOutputLight", "ShaderNodeOutputAOV"}
IMG_EXT = (".png", ".jpg", ".jpeg", ".hdr", ".exr", ".tif", ".tiff", ".webp")


class PasteError(Exception):
    pass


# ------------------------------------------------------------------ helpers
def _addon_prefs():
    for key in (__package__, __name__):
        try:
            if key:
                return bpy.context.preferences.addons[key].preferences
        except Exception:
            pass
    return None


def _image_dirs():
    dirs = []
    if _TEST_IMAGE_DIRS:
        return list(_TEST_IMAGE_DIRS)
    pr = _addon_prefs()
    if pr and pr.texture_dir:
        dirs.append(bpy.path.abspath(pr.texture_dir))
    here = os.path.dirname(os.path.abspath(__file__))
    dirs += [os.path.join(here, "textures"), os.path.join(here, "shader_dict_textures"),
             os.path.join(os.path.dirname(here), "shader_dict_textures"), here]
    if bpy.data.filepath:
        b = os.path.dirname(bpy.data.filepath); dirs += [os.path.join(b, "textures"), b]
    # texture packs downloaded from the website (shader_dict_textures_1..4.zip unzipped in Downloads / Desktop / Documents)
    home = os.path.expanduser("~")
    for sub in ("Downloads", "Desktop", "Documents", "다운로드", "바탕 화면", "문서", ""):
        base = os.path.join(home, sub) if sub else home
        try:
            for nm in sorted(os.listdir(base)):
                if nm.lower().startswith("shader_dict_textures"):
                    dirs.append(os.path.join(base, nm))
        except Exception:
            pass
    # Blender's own studio-light HDRIs (forest.exr, city.exr ...) that some recipes use as the world image
    try:
        dirs.append(bpy.utils.system_resource("DATAFILES", path="studiolights/world"))
    except Exception:
        pass
    return [d for d in dirs if d and os.path.isdir(d)]


_TEST_IMAGE_DIRS = []
_INDEX = {}


def _dir_index(d):
    """filename -> path for every image under d (3 folder levels), cached per paste."""
    if d in _INDEX:
        return _INDEX[d]
    idx = {}
    base = d.rstrip(os.sep).count(os.sep)
    for root, dirs, files in os.walk(d):
        if root.count(os.sep) - base >= 3:
            dirs[:] = []
        for f in files:
            idx.setdefault(f, os.path.join(root, f))
            idx.setdefault(f.lower(), os.path.join(root, f))
    _INDEX[d] = idx
    return idx


def _find_image_file(name):
    for d in _image_dirs():
        p = os.path.join(d, name)
        if os.path.isfile(p):
            return p
        idx = _dir_index(d)
        hit = idx.get(name) or idx.get(name.lower())
        if hit:
            return hit
    return None


def _get_image(spec, warnings):
    name = spec.get("name") or "image"
    img = bpy.data.images.get(name)
    if img is None:
        path = _find_image_file(name)
        if path:
            img = bpy.data.images.load(path, check_existing=True)
        else:
            img = bpy.data.images.new(name, 256, 256, alpha=True)
            img.generated_type = "COLOR_GRID"
            warnings.append(_t(f"이미지 '{name}'을(를) 찾지 못해 임시 격자 이미지를 넣었어요. Image Texture 노드에서 [Open]으로 바꿔 주세요.",
                                 f"Image '{name}' was not found, so a temporary grid image was used. Replace it with [Open] on the Image Texture node."))
    cs = spec.get("cs")
    if cs:
        try:
            img.colorspace_settings.name = cs
        except Exception:
            pass
    if spec.get("alpha"):
        try:
            img.alpha_mode = spec["alpha"]
        except Exception:
            pass
    return img


def _set_socket_value(sock, v):
    if not hasattr(sock, "default_value"):
        return False
    try:
        cur = sock.default_value
        if isinstance(v, list):
            n = len(cur)
            vv = list(v)[:n] + ([1.0] * (n - len(v)) if len(v) < n else [])
            sock.default_value = vv
        elif isinstance(cur, bool):
            sock.default_value = bool(v)
        elif isinstance(cur, int):
            sock.default_value = int(v)
        else:
            sock.default_value = v
        return True
    except Exception:
        return False


def _find_socket(coll, idx, ident, name=None):
    if ident is not None:
        for s in coll:
            if s.identifier == ident:
                return s
    if idx is not None and 0 <= idx < len(coll):
        return coll[idx]
    if name is not None or ident is not None:
        nm = name or ident
        enabled = [s for s in coll if s.name == nm and s.enabled]
        if enabled:
            return enabled[0]
        for s in coll:
            if s.name == nm:
                return s
    return None


POINTER_PROPS = {"object": "objects"}


def _apply_props(node, props, warnings):
    # enums first (they change which sockets exist), then the rest
    items = sorted(props.items(), key=lambda kv: 0 if isinstance(kv[1], str) else 1)
    for k, v in items:
        if k in ("shrink", "label_size") and node.bl_idname != "NodeFrame":
            continue
        if k in POINTER_PROPS:
            ob = getattr(bpy.data, POINTER_PROPS[k]).get(v)
            if ob is None and k == "object":
                # 11-25: the recipe is driven by an Empty (e.g. R46 'ScanEmpty'); make one so the paste works right away
                try:
                    ob = bpy.data.objects.new(v, None); ob.empty_display_type = "PLAIN_AXES"; ob.empty_display_size = 0.5
                    act = bpy.context.view_layer.objects.active
                    ob.location = (act.location.x, act.location.y, act.location.z + 1.0) if act is not None else (0.0, 0.0, 1.0)
                    bpy.context.scene.collection.objects.link(ob)
                    warnings.append(_t(f"'{node.name}': 오브젝트 '{v}'가 없어서 빈 오브젝트(Empty)를 새로 만들어 연결했어요. 이 Empty를 움직이면 무늬가 따라 움직여요.",
                                       f"'{node.name}': object '{v}' was missing, so a new Empty was created and linked. Move this Empty to move the pattern."))
                except Exception:
                    ob = None
            if ob is not None:
                setattr(node, k, ob)
            else:
                warnings.append(_t(f"'{node.name}': 오브젝트 '{v}'가 이 파일에 없어서 비워 두었어요.", f"'{node.name}': object '{v}' is not in this file, so it was left empty."))
            continue
        if k in ("script", "ies", "particle_system", "bytecode_hash"):
            continue
        if k == "filepath":
            continue
        try:
            setattr(node, k, v)
        except Exception:
            pass


def _apply_ramp(node, ramp):
    cr = node.color_ramp
    try:
        cr.interpolation = ramp.get("interp", "LINEAR")
    except Exception:
        pass
    stops = sorted(ramp.get("stops", []), key=lambda s: s[0])
    if not stops:
        return
    els = cr.elements
    while len(els) > 1:
        els.remove(els[len(els) - 1])
    def col(c):
        c = list(c); return c[:4] + [1.0] * (4 - len(c))
    els[0].position = stops[0][0]; els[0].color = col(stops[0][1])
    for pos, c in stops[1:]:            # ascending positions -> each new stop lands at the end
        els.new(pos)
        els[len(els) - 1].color = col(c)


def _apply_curves(node, curves):
    mp = node.mapping
    for ci, pts in curves:
        if ci >= len(mp.curves):
            continue
        c = mp.curves[ci]
        while len(c.points) > len(pts):
            c.points.remove(c.points[-1])
        while len(c.points) < len(pts):
            c.points.new(0.5, 0.5)
        for p, (x, y) in zip(c.points, pts):
            p.location = (x, y)
    try:
        mp.update()
    except Exception:
        pass


def _text_block(name, body):
    t = bpy.data.texts.get(name)
    if t is None:
        t = bpy.data.texts.new(name)
    t.clear(); t.write(body)
    return t


def _setup_osl(node, text, warnings):
    """OSL sockets are created when Cycles compiles the script -> compile with Cycles even if the scene uses EEVEE."""
    sc = bpy.context.scene
    old = sc.render.engine
    try:
        if old != "CYCLES":
            sc.render.engine = "CYCLES"
        node.mode = "INTERNAL"
        node.script = text            # RNA update -> Cycles compiles the script and adds its sockets
        if len(node.inputs) == 0 and len(node.outputs) == 0:
            node.script = None; node.script = text
    finally:
        if sc.render.engine != old:
            sc.render.engine = old
    if len(node.inputs) == 0 and len(node.outputs) == 0:
        warnings.append(_t("OSL 스크립트를 컴파일하지 못했어요. Cycles(CPU) + Render Properties › Open Shading Language를 켜고 Script 노드의 새로고침 버튼을 눌러 주세요.", "The OSL script could not be compiled. Turn on Cycles (CPU) + Render Properties › Open Shading Language and press the refresh button on the Script node."))
    elif sc.render.engine != "CYCLES" or getattr(sc.cycles, "shading_system", True) is False:
        warnings.append(_t("Script(OSL) 노드는 Cycles + CPU + Open Shading Language 켜기에서만 렌더돼요.", "Script (OSL) nodes only render in Cycles + CPU with Open Shading Language on."))


def _make_group(gspec, warnings):
    name = gspec.get("name") or "Group"
    tr = gspec["tree"]
    ng = bpy.data.node_groups.new(name, "ShaderNodeTree")
    itf = tr.get("interface", [])
    def ident_num(it):
        try: return int(str(it.get("identifier", "")).rsplit("_", 1)[1])
        except Exception: return 10 ** 6 + itf.index(it)
    created = {}
    for it in sorted(itf, key=ident_num):      # creation order decides the socket identifiers (Socket_0, Socket_1…) links refer to
        try:
            s = ng.interface.new_socket(it["name"], in_out=it["in_out"], socket_type=it["socket_type"])
            if "default" in it and hasattr(s, "default_value"):
                try:
                    s.default_value = it["default"] if not isinstance(it["default"], list) else it["default"][:len(s.default_value)]
                except Exception:
                    pass
            for k in ("min_value", "max_value"):
                if k in it and hasattr(s, k):
                    try: setattr(s, k, it[k])
                    except Exception: pass
            created[id(it)] = s
        except Exception as ex:
            warnings.append(_t(f"그룹 '{name}' 소켓 '{it.get('name')}' 생성 실패: {ex}", f"Group '{name}': could not create socket '{it.get('name')}': {ex}"))
    for pos, it in enumerate(itf):              # then restore the original display order
        s = created.get(id(it))
        if s is not None:
            try: ng.interface.move(s, pos)
            except Exception: pass
    build_nodes(ng, tr, warnings, layout=True)
    return ng


# ------------------------------------------------------------------ version compatibility (clips made in Blender 4.5 -> 5.x)
# A clip stores only values that differ from Blender 4.5 defaults. Blender 5.0+ changed some defaults/enums,
# so first put back the 4.5 default, then the clip's own values are applied on top (setting a 4.5 default on 4.5 is a no-op).
LEGACY_INPUT_DEFAULTS = {
    "ShaderNodeBsdfPrincipled": {"Subsurface Scale": 0.05},
    "ShaderNodeSubsurfaceScattering": {"Scale": 0.05},
    "ShaderNodeMix": {"Factor_Float": 0.5},
    "ShaderNodeBlackbody": {"Temperature": 1500.0},
}
LEGACY_ENUM_RENAMES = {("ShaderNodeTexSky", "sky_type"): {"NISHITA": "SINGLE_SCATTERING"}}
# Blender 5.0 improved Random Walk subsurface; files from 4.x are versioned to "Random Walk (Legacy)" to keep their look.
LEGACY_ENUM_DEFAULTS = {("ShaderNodeBsdfPrincipled", "subsurface_method"): ("RANDOM_WALK", "RANDOM_WALK_LEGACY"),
                        ("ShaderNodeSubsurfaceScattering", "falloff"): ("RANDOM_WALK", "RANDOM_WALK_LEGACY")}
LEGACY_PROP_RENAMES = {("ShaderNodeTexSky", "dust_density"): "aerosol_density"}
REMOVED_NODES = {"ShaderNodeTexPointDensity": ("Point Density 노드는 블렌더 5.0부터 없어졌어요. 지오메트리 노드의 [Points to Volume]으로 볼륨을 만들어 대신 쓰세요.",
                                              "The Point Density node was removed in Blender 5.0. Use Geometry Nodes [Points to Volume] instead.")}


_CLIP_LEGACY = True     # clip format v1 = made with Blender 4.5 (set per paste in paste_json)


def _legacy_prepare(node, spec):
    if not _CLIP_LEGACY:
        return
    t = node.bl_idname
    for ident, v in LEGACY_INPUT_DEFAULTS.get(t, {}).items():
        s = _find_socket(node.inputs, None, ident)
        if s is not None:
            _set_socket_value(s, v)
    p = spec.get("p", {})
    if True:
        for (nt_, prop), (old, new) in LEGACY_ENUM_DEFAULTS.items():
            if t == nt_ and p.get(prop, old) == old and hasattr(node, prop):
                try:
                    if new in {e.identifier for e in node.bl_rna.properties[prop].enum_items}:
                        setattr(node, prop, new)
                except Exception:
                    pass
    if t == "ShaderNodeTexSky":
        if "sky_type" not in p and hasattr(node, "sky_type"):
            for old in ("NISHITA", "SINGLE_SCATTERING"):        # 4.5 default model
                try:
                    node.sky_type = old; break
                except Exception:
                    pass
        if "altitude" not in p and hasattr(node, "altitude"):
            try: node.altitude = 0.0                            # 4.5 default (5.0 changed it to 100 m)
            except Exception: pass


_CLIP_MODERN_ON_OLD = False   # clip format v2 = made with Blender 5.x, pasted into Blender 4.x
MODERN_PROP_RENAMES = {("ShaderNodeTexSky", "aerosol_density"): "dust_density"}
MODERN_ENUM_RENAMES = {("ShaderNodeTexSky", "sky_type"): {"SINGLE_SCATTERING": "NISHITA", "MULTIPLE_SCATTERING": "NISHITA"},
                       ("ShaderNodeBsdfPrincipled", "subsurface_method"): {"RANDOM_WALK_LEGACY": "RANDOM_WALK"},
                       ("ShaderNodeSubsurfaceScattering", "falloff"): {"RANDOM_WALK_LEGACY": "RANDOM_WALK"}}


def _enum_ok(node, prop, v):
    try:
        return v in {e.identifier for e in node.bl_rna.properties[prop].enum_items}
    except Exception:
        return True


def _modern_prepare(node, spec):
    """clip stores only values that differ from Blender 5.x defaults -> on 4.x first put the 5.x defaults back."""
    if not _CLIP_MODERN_ON_OLD or _CT is None:
        return
    d = getattr(_CT, "DEFAULTS_5X_VS_45", {}).get(node.bl_idname)
    if not d:
        return
    for ident, v in d.get("i", {}).items():
        s = _find_socket(node.inputs, None, ident)
        if s is not None:
            _set_socket_value(s, v)
    p = spec.get("p", {})
    for prop, v in d.get("p", {}).items():
        if prop in p:
            continue
        prop2 = MODERN_PROP_RENAMES.get((node.bl_idname, prop), prop)
        if not hasattr(node, prop2):
            continue
        if isinstance(v, str):
            v = MODERN_ENUM_RENAMES.get((node.bl_idname, prop2), {}).get(v, v)
            if not _enum_ok(node, prop2, v):
                continue
        try:
            setattr(node, prop2, v)
        except Exception:
            pass


def _modern_props(node, props):
    if not _CLIP_MODERN_ON_OLD:
        return props
    out = {}
    for k, v in props.items():
        k2 = MODERN_PROP_RENAMES.get((node.bl_idname, k), k)
        if not hasattr(node, k2) and hasattr(node, k):
            k2 = k
        if isinstance(v, str):
            ren = MODERN_ENUM_RENAMES.get((node.bl_idname, k2))
            if ren and not _enum_ok(node, k2, v):
                v = ren.get(v, v)
        out[k2] = v
    return out


def _legacy_props(node, props):
    if not _CLIP_LEGACY:
        return props
    out = {}
    for k, v in props.items():
        k2 = LEGACY_PROP_RENAMES.get((node.bl_idname, k), k)
        if not hasattr(node, k2) and hasattr(node, k):
            k2 = k
        led = LEGACY_ENUM_DEFAULTS.get((node.bl_idname, k2))
        if led and v == led[0] and hasattr(node, k2):
            try:
                if led[1] in {e.identifier for e in node.bl_rna.properties[k2].enum_items}:
                    v = led[1]
            except Exception:
                pass
        ren = LEGACY_ENUM_RENAMES.get((node.bl_idname, k2))
        if ren and isinstance(v, str):
            try:
                ok = v in {e.identifier for e in node.bl_rna.properties[k2].enum_items}
            except Exception:
                ok = True
            if not ok:
                v = ren.get(v, v)
        out[k2] = v
    return out


# ------------------------------------------------------------------ dynamic sockets (Blender 5.x: Repeat / Closure / Bundle items)
ITEM_COLLECTIONS = ("repeat_items", "bundle_items", "input_items", "output_items", "capture_items", "enum_items")


def _make_items(node, spec, warnings):
    items = spec.get("items")
    if not items:
        return
    for coll, lst in items.items():
        c = getattr(node, coll, None)
        if c is None:
            continue
        try:
            have = [it.name for it in c]
        except Exception:
            have = []
        if have == [nm for _ty, nm in lst]:
            continue
        if coll == "enum_items":
            # Menu Switch: rename the default items and add the rest, so socket identifiers stay Item_0, Item_1, ...
            # (clear() + new() would number them Item_2, Item_3 ... and links by identifier would miss)
            try:
                for i, (_ty, nm) in enumerate(lst):
                    if i < len(c): c[i].name = nm
                    else: c.new(nm)
                while len(c) > len(lst): c.remove(c[len(c) - 1])
            except Exception as ex:
                warnings.append(_t(f"'{node.name}': 메뉴 항목을 만들지 못했어요 ({ex}).", f"'{node.name}': could not create the menu items ({ex})."))
            continue
        try:
            c.clear()
        except Exception:
            pass
        for ty, nm in lst:
            try:
                c.new(nm) if coll == "enum_items" else c.new(ty, nm)   # Menu Switch items have a name only
            except Exception as ex:
                warnings.append(_t(f"'{node.name}': '{nm}' 소켓을 만들지 못했어요 ({ex}).", f"'{node.name}': could not create socket '{nm}' ({ex})."))


# ------------------------------------------------------------------ core
def build_nodes(nt, tr, warnings, layout=True, origin=(0.0, 0.0), frame_label=None, keep_outputs_inactive=False):
    """create nodes+links of TREE inside node tree nt. returns {json_name: node}"""
    made = {}
    for spec in tr.get("nodes", []):
        t = spec["t"]
        try:
            node = nt.nodes.new(t)
        except Exception:
            if t in REMOVED_NODES:
                warnings.append(f"'{spec.get('n')}': {_t(*REMOVED_NODES[t])}")
            elif bpy.app.version < (5, 0, 0):
                warnings.append(_t(f"'{spec.get('n')}' ({t}) 노드는 블렌더 5.0 이상의 셰이더에서만 쓸 수 있어 건너뛰었어요. 이 레시피는 5.x에서 붙여 넣어 주세요.",
                                   f"'{spec.get('n')}' ({t}) can only be used in shaders in Blender 5.0+, so it was skipped. Paste this recipe in 5.x."))
            else:
                warnings.append(_t(f"'{spec.get('n')}' 노드 종류({t})를 이 블렌더 버전에서 만들 수 없어 건너뛰었어요.", f"'{spec.get('n')}': node type {t} does not exist in this Blender version, skipped."))
            continue
        node.name = spec.get("n", node.name)
        if spec.get("l") and spec["l"] != node.bl_label:
            node.label = spec["l"]
        made[spec.get("n")] = node
        if spec.get("g"):
            node.node_tree = _make_group(spec["g"], warnings)
        _legacy_prepare(node, spec)
        _modern_prepare(node, spec)
        _apply_props(node, _modern_props(node, _legacy_props(node, spec.get("p", {}))), warnings)
        _make_items(node, spec, warnings)
    # zones (Repeat / Closure ...): pair input with output before values and links (Blender 5.x)
    for spec in tr.get("nodes", []):
        if spec.get("pair") and spec.get("n") in made and spec["pair"] in made:
            try:
                made[spec["n"]].pair_with_output(made[spec["pair"]])
            except Exception as ex:
                warnings.append(_t(f"'{spec['n']}' 존(zone)을 '{spec['pair']}'와 짝짓지 못했어요: {ex}", f"Could not pair zone '{spec['n']}' with '{spec['pair']}': {ex}"))
    for spec in tr.get("nodes", []):
        node = made.get(spec.get("n"))
        if node is None:
            continue
        if spec.get("img") and hasattr(node, "image"):
            node.image = _get_image(spec["img"], warnings)
        if spec.get("script") is not None and node.bl_idname == "ShaderNodeScript":
            _setup_osl(node, _text_block(spec.get("p", {}).get("script", node.name + ".osl"), spec["script"]), warnings)
        if spec.get("ies") is not None and node.bl_idname == "ShaderNodeTexIES":
            node.mode = "INTERNAL"; node.ies = _text_block(spec.get("p", {}).get("ies", node.name + ".ies"), spec["ies"])
        for idx, ident, v in spec.get("i", []):
            s = _find_socket(node.inputs, idx, ident)
            if s is None or not _set_socket_value(s, v):
                warnings.append(_t(f"'{node.name}'의 입력 '{ident}' 값을 넣지 못했어요.", f"Could not set input '{ident}' on '{node.name}'."))
        for k, v in spec.get("i_by_name", {}).items():
            s = _find_socket(node.inputs, None, None, k)
            if s is not None: _set_socket_value(s, v)
        for idx, ident, v in spec.get("o", []):
            s = _find_socket(node.outputs, idx, ident)
            if s is not None: _set_socket_value(s, v)
        if spec.get("ramp") and node.bl_idname == "ShaderNodeValToRGB":
            _apply_ramp(node, spec["ramp"])
        if spec.get("curves") and hasattr(node, "mapping"):
            _apply_curves(node, spec["curves"])
    for spec in tr.get("nodes", []):
        if spec.get("parent") and spec.get("n") in made and spec["parent"] in made:
            made[spec["n"]].parent = made[spec["parent"]]
    for lk in tr.get("links", []):
        fn, fi, fid, tn, ti, tid = lk[:6]
        a, b = made.get(fn), made.get(tn)
        if a is None or b is None:
            warnings.append(_t(f"연결 {fn} → {tn}: 노드가 없어 건너뛰었어요.", f"Link {fn} → {tn}: node missing, skipped.")); continue
        so = _find_socket(a.outputs, fi, fid); si = _find_socket(b.inputs, ti, tid)
        if so is None or si is None:
            warnings.append(_t(f"연결 {fn}.{fid} → {tn}.{tid}: 소켓을 찾지 못했어요.", f"Link {fn}.{fid} → {tn}.{tid}: socket not found.")); continue
        nt.links.new(so, si)
    if keep_outputs_inactive:
        for n in made.values():
            if n.bl_idname in OUTPUT_TYPES and hasattr(n, "is_active_output"):
                n.is_active_output = False
    if layout:
        auto_layout(nt, made, origin)
    if frame_label:
        fr = nt.nodes.new("NodeFrame"); fr.label = frame_label; fr.name = "ShaderDict " + frame_label
        fr.label_size = 16; fr.shrink = True
        for n in made.values():
            if n.parent is None and n.bl_idname != "NodeFrame":
                n.parent = fr
    return made


_BASE = None
def _est_height(n):
    """rough drawn height of a node (node.dimensions is 0 until the editor draws it)."""
    global _BASE
    if _BASE is None:
        _BASE = set(bpy.types.ShaderNode.bl_rna.properties.keys()) | set(bpy.types.Node.bl_rna.properties.keys())
    h = 36 + 22 * sum(1 for s in n.outputs if s.enabled and not getattr(s, "hide", False))
    for s in n.inputs:
        if s.enabled and not getattr(s, "hide", False):
            h += 22
    for p in n.bl_rna.properties:          # buttons drawn in the node body (dropdowns, check boxes)
        if p.identifier in _BASE or p.is_readonly: continue
        if p.type == "ENUM": h += 26
        elif p.type == "BOOLEAN": h += 22
    t = n.bl_idname
    if t == "ShaderNodeValToRGB": h += 110
    elif getattr(n, "mapping", None) is not None: h += 200
    elif t in ("ShaderNodeTexImage", "ShaderNodeTexEnvironment"): h += 130
    elif t == "ShaderNodeRGB": h += 160
    if t == "ShaderNodeBsdfPrincipled": h = 36 + 22 * 7 + 18 * 9     # sub panels are collapsed by default
    return h


def auto_layout(nt, made, origin=(0.0, 0.0)):
    nodes = [n for n in made.values() if n.bl_idname != "NodeFrame"]
    if not nodes:
        return
    ids = {n.name: n for n in nodes}
    outs = defaultdict(list)       # node -> downstream nodes
    ins = defaultdict(list)
    for l in nt.links:
        if l.from_node.name in ids and l.to_node.name in ids:
            outs[l.from_node.name].append(l.to_node.name)
            ins[l.to_node.name].append((list(l.to_node.inputs).index(l.to_socket), l.from_node.name))
    col = {}
    def depth(nm, seen=()):
        if nm in col: return col[nm]
        if nm in seen: return 0
        d = 0 if not outs[nm] else 1 + max(depth(x, seen + (nm,)) for x in outs[nm])
        col[nm] = d; return d
    for nm in ids: depth(nm)
    # order inside each column: follow the output's inputs from top to bottom (DFS)
    order = []
    def visit(nm):
        if nm in order: return
        order.append(nm)
        for _i, src in sorted(ins[nm]):
            visit(src)
    roots = sorted([nm for nm in ids if not outs[nm]], key=lambda nm: (ids[nm].bl_idname not in OUTPUT_TYPES, nm))
    for r in roots: visit(r)
    for nm in ids:
        if nm not in order: order.append(nm)
    cols = defaultdict(list)
    for nm in order: cols[col[nm]].append(nm)
    ox, oy = origin
    for c, names in cols.items():
        y = oy
        for nm in names:
            n = ids[nm]
            n.location = (ox - c * 300.0, y)
            y -= _est_height(n) + 40


def paste_json(context, text, mode="NEW"):
    """mode: NEW = 새 머티리얼/월드 만들기, ADD = 지금 머티리얼(월드) 안에 프레임으로 추가. returns (message, warnings)"""
    try:
        data = json.loads(text)
        global _CLIP_LEGACY, _CLIP_MODERN_ON_OLD
        try:
            _CLIP_LEGACY = int(data.get("v", 1)) < 2
        except Exception:
            _CLIP_LEGACY = True
        _CLIP_MODERN_ON_OLD = (not _CLIP_LEGACY) and bpy.app.version < (5, 0, 0)
        _INDEX.clear()
    except Exception:
        raise PasteError(_t("클립보드 내용이 쉐이더 사전 JSON이 아니에요. 앱에서 '블렌더로 복사'를 다시 눌러 주세요.", "The clipboard does not hold Shader Dictionary JSON. Press 'Copy to Blender' in the app again."))
    if not isinstance(data, dict) or data.get("fmt") != FMT:
        raise PasteError(_t("쉐이더 사전 형식이 아니에요 (fmt 값이 다름). 앱에서 '블렌더로 복사'한 내용인지 확인해 주세요.", "Not the Shader Dictionary format (fmt differs). Make sure it was copied with 'Copy to Blender'."))
    if data.get("v", 1) > 2:
        raise PasteError(_t("더 새로운 형식의 데이터예요. 애드온을 최신으로 바꿔 주세요.", "This data uses a newer format. Please update the add-on."))
    tree = data.get("tree") or {}
    title = data.get("title") or "Shader Dictionary"
    variant = data.get("variant") or ""
    short = " · ".join(part.split("›")[-1].strip() for part in variant.split(" · ")) if variant else ""
    full = f"{title} [{short}]" if short else title
    while len(full.encode("utf-8")) > 63:          # Blender names are max 63 bytes
        full = full[:-1]
    target = data.get("target", "material")
    warnings = []
    ob = context.active_object if hasattr(context, "active_object") else None
    if target == "world":
        sc = context.scene
        if mode == "ADD" and sc.world is not None:
            w = sc.world; w.use_nodes = True
            org = _origin_below(w.node_tree)
            build_nodes(w.node_tree, tree, warnings, origin=org, frame_label=full, keep_outputs_inactive=True)
            return _t(f"월드 '{w.name}'에 '{full}' 노드를 프레임으로 섞어 넣었어요 (붙여넣은 World Output은 꺼 둠).", f"Mixed '{full}' into world '{w.name}' as a frame (the pasted World Output is inactive)."), warnings
        w = bpy.data.worlds.new(full); w.use_nodes = True; w.node_tree.nodes.clear()
        build_nodes(w.node_tree, tree, warnings)
        sc.world = w
        return _t(f"새 월드 '{w.name}'를 만들어 장면에 적용했어요.", f"Created new world '{w.name}' and assigned it to the scene."), warnings
    if target == "light":
        if ob is None or ob.type != "LIGHT":
            raise PasteError(_t("이 레시피는 조명(라이트) 노드예요. 먼저 라이트 오브젝트를 선택한 뒤 붙여넣어 주세요.", "This recipe is a light node tree. Select a light object first, then paste."))
        L = ob.data; L.use_nodes = True
        if mode == "ADD":
            build_nodes(L.node_tree, tree, warnings, origin=_origin_below(L.node_tree), frame_label=full, keep_outputs_inactive=True)
        else:
            L.node_tree.nodes.clear(); build_nodes(L.node_tree, tree, warnings)
        return _t(f"라이트 '{ob.name}'에 '{full}' 노드를 넣었어요.", f"Put '{full}' into light '{ob.name}'."), warnings
    # material
    if mode == "ADD":
        mat = ob.active_material if ob is not None else None
        if mat is None:
            raise PasteError(_t("섞어 넣을 재질이 없어요. 오브젝트를 선택하고 재질을 하나 만든 뒤 다시 해 보세요 (또는 [새 재질로 붙여넣기] 사용).", "There is no material to mix into. Select an object with a material and try again (or use [Paste as New Material])."))
        mat.use_nodes = True
        build_nodes(mat.node_tree, tree, warnings, origin=_origin_below(mat.node_tree), frame_label=full, keep_outputs_inactive=True)
        return _t(f"재질 '{mat.name}'에 '{full}' 노드를 프레임으로 섞어 넣었어요 (붙여넣은 Material Output은 꺼 둠).", f"Mixed '{full}' into material '{mat.name}' as a frame (the pasted Material Output is inactive)."), warnings
    mat = bpy.data.materials.new(full); mat.use_nodes = True; mat.node_tree.nodes.clear()
    for k, v in (data.get("settings") or {}).items():
        try: setattr(mat, k, v)
        except Exception: pass
    build_nodes(mat.node_tree, tree, warnings)
    if ob is not None and hasattr(ob.data, "materials"):
        if len(ob.material_slots) == 0:
            ob.data.materials.append(mat)
        else:
            ob.material_slots[ob.active_material_index].material = mat
        return _t(f"새 재질 '{mat.name}'을(를) '{ob.name}'에 적용했어요.", f"Applied new material '{mat.name}' to '{ob.name}'."), warnings
    mat.use_fake_user = True
    return _t(f"선택된 오브젝트가 없어 재질 '{mat.name}'만 만들었어요 (가짜 사용자 켬).", f"No object selected, so only material '{mat.name}' was created (fake user on)."), warnings


def _origin_below(nt):
    if not nt.nodes:
        return (0.0, 0.0)
    ys = [n.location[1] - _est_height(n) for n in nt.nodes if n.parent is None]
    xs = [n.location[0] for n in nt.nodes if n.parent is None]
    return (max(xs) if xs else 0.0, (min(ys) if ys else 0.0) - 200.0)


# ------------------------------------------------------------------ UI
class SHADERDICT_OT_paste(bpy.types.Operator):
    """쉐이더 사전 앱에서 '블렌더로 복사'한 노드 트리를 붙여넣어요 / Paste a node tree copied with 'Copy to Blender'"""
    bl_idname = "shader_dict.paste"
    bl_label = "Shader Dictionary Paste"
    bl_options = {"REGISTER", "UNDO"}

    mode: bpy.props.EnumProperty(name="Mode", items=[
        ("NEW", "Paste as New Material", "새 재질로 붙여넣기"),
        ("ADD", "Mix into Current Material", "지금 재질에 섞어 넣기")], default="NEW")
    text: bpy.props.StringProperty(name="JSON", description="empty = read the clipboard (for tests)", default="", options={"SKIP_SAVE", "HIDDEN"})

    @classmethod
    def description(cls, context, properties):
        if getattr(properties, "mode", "NEW") == "ADD":
            return _t("지금 선택한 오브젝트의 재질(월드·라이트) 안에 복사한 노드를 프레임으로 묶어 아래쪽에 넣어요. "
                      "원래 노드는 그대로 두고, 붙여넣은 출력 노드는 꺼 두니 원하는 소켓끼리 직접 연결해 섞으세요.",
                      "Adds the copied nodes inside the selected object's current material (or world/light), grouped in a frame below the "
                      "existing nodes. Your nodes stay untouched and the pasted output node is inactive, so wire the sockets you want to mix.")
        return _t("복사한 노드 트리로 새 재질을 만들어 선택한 오브젝트에 바로 적용해요 (월드 레시피는 새 월드, 라이트 레시피는 선택한 라이트). "
                  "기존 재질은 지워지지 않아요.",
                  "Creates a new material from the copied node tree and applies it to the selected object (world recipes make a new world, "
                  "light recipes go into the selected light). Existing materials are not deleted.")

    def execute(self, context):
        txt = self.text or context.window_manager.clipboard
        if not txt or not txt.strip():
            self.report({"ERROR"}, _t("클립보드가 비어 있어요. 앱에서 '블렌더로 복사'를 먼저 눌러 주세요.", "The clipboard is empty. Press 'Copy to Blender' in the app first."))
            return {"CANCELLED"}
        try:
            msg, warns = paste_json(context, txt, self.mode)
        except PasteError as ex:
            self.report({"ERROR"}, str(ex)); return {"CANCELLED"}
        except Exception as ex:
            self.report({"ERROR"}, _t(f"붙여넣는 중 문제가 생겼어요: {ex}", f"Something went wrong while pasting: {ex}")); return {"CANCELLED"}
        for w in warns[:8]:
            self.report({"WARNING"}, w)
        if len(warns) > 8:
            self.report({"WARNING"}, _t(f"…외 경고 {len(warns) - 8}개 (Info 창 참고)", f"…and {len(warns) - 8} more warnings (see the Info editor)"))
        self.report({"INFO"}, msg)
        return {"FINISHED"}


def _bundled_dir():
    d = os.path.join(os.path.dirname(os.path.abspath(__file__)), "textures")
    return d if os.path.isdir(d) else None


class SHADERDICT_PT_panel(bpy.types.Panel):
    bl_label = "Shader Dictionary"
    bl_idname = "SHADERDICT_PT_panel"
    bl_space_type = "NODE_EDITOR"
    bl_region_type = "UI"
    bl_category = "Shader Dict"

    @classmethod
    def poll(cls, context):
        return context.space_data is not None and getattr(context.space_data, "tree_type", "") == "ShaderNodeTree"

    def draw(self, context):
        col = self.layout.column(align=False)
        col.label(text=_t("① 앱에서 '블렌더로 복사' 클릭", "① Click 'Copy to Blender' in the app"))
        col.label(text=_t("② 오브젝트 선택 후 아래 버튼", "② Select an object, then a button"))
        r = col.row(); r.scale_y = 1.6
        op = r.operator(SHADERDICT_OT_paste.bl_idname, text=_t("새 재질로 붙여넣기", "Paste as New Material"), icon="PASTEDOWN"); op.mode = "NEW"
        op = col.operator(SHADERDICT_OT_paste.bl_idname, text=_t("지금 재질에 섞어 넣기", "Mix into Current Material"), icon="ADD"); op.mode = "ADD"
        pr = _addon_prefs()
        col.separator()
        bd = _bundled_dir()
        if bd:
            col.label(text=_t("함께 든 텍스처: 자동으로 찾음", "Bundled textures: found automatically"), icon="CHECKMARK")
        if pr is not None:
            col.label(text=_t("다른 텍스처 폴더 (선택):", "Extra texture folder (optional):"))
            col.prop(pr, "texture_dir", text="")


class SHADERDICT_Prefs(bpy.types.AddonPreferences):
    bl_idname = __package__ or __name__
    texture_dir: bpy.props.StringProperty(name="Texture folder / 텍스처 폴더", subtype="DIR_PATH", default="",
                                          description="함께 든 textures 폴더는 자동으로 찾아요. 다른 곳의 이미지를 쓰려면 지정하세요 / "
                                                      "The bundled textures folder is found automatically; set this only for images stored elsewhere")
    ui_language: bpy.props.EnumProperty(name="Language / 언어", items=[
        ("AUTO", "Auto (Blender) / 자동", "블렌더 인터페이스 언어를 따라가요 / Follow Blender's interface language"),
        ("KO", "한국어", "한국어로 표시"), ("EN", "English", "Show in English")], default="AUTO")

    def draw(self, context):
        self.layout.prop(self, "ui_language")
        self.layout.prop(self, "texture_dir")
        bd = _bundled_dir()
        self.layout.label(text=(_t("함께 든 텍스처 폴더: ", "Bundled textures: ") + (bd or _t("없음", "none"))))


CLASSES = (SHADERDICT_Prefs, SHADERDICT_OT_paste, SHADERDICT_PT_panel)


_KO = {
    ("*", "Shader Dictionary"): "쉐이더 사전",
    ("*", "Shader Dict"): "쉐이더 사전",
    ("Operator", "Shader Dictionary Paste"): "쉐이더 사전 붙여넣기",
    ("*", "Shader Dictionary Paste"): "쉐이더 사전 붙여넣기",
    ("*", "Paste as New Material"): "새 재질로 붙여넣기",
    ("*", "Mix into Current Material"): "지금 재질에 섞어 넣기",
    ("*", "Mode"): "방식",
}


def register():
    try:
        bpy.app.translations.register(__name__, {"ko_KR": _KO, "ko": _KO})
    except Exception:
        pass
    for c in CLASSES:
        bpy.utils.register_class(c)


def unregister():
    for c in reversed(CLASSES):
        bpy.utils.unregister_class(c)
    try:
        bpy.app.translations.unregister(__name__)
    except Exception:
        pass


if __name__ == "__main__":
    register()
